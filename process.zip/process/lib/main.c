#include "lib.h"


void schedule(void);

int main(void)
{
    printf("\nFirst Process 20KB");
    printf("\nSecond Process 30KB");
    printf("\nThird Process 10KB");
    printf("\nFourth Process 14KB");
    printf("\nFifthProcess 16KB");
    schedule();
    return 0;
}

void schedule(void){
    printf("\nThird Process 10KB");
    printf("\nFourth Process 14KB");
    printf("\nFifth Process 16KB");
    printf("\nFirst Process 20KB");
    printf("\nSecond Process 30KB");
}