#ifndef _LIB_H_
#define _LIB_H_

int printf(const char *format, ...);

#endif