#include "trap.h"

void KMain(void)
{
   init_idt();
}