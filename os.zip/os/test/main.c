#include "lib.h"

int main(void)
{
    printf("test process starts \n");
    
    return 0;
}